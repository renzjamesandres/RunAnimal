/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jhnnn
 */
class Cat extends Animal {
    void eat() {
        System.out.println("Cats love to eat fish.");
    }

    void sleep() {
        System.out.println("Cats sleep for 12-16 hours a day.");
    }

    void makeSound() {
        System.out.println("Meow");
    }
}