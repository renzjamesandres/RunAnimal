/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jhnnn
 */
class Dog extends Animal {
    void eat() {
        System.out.println("Dogs love to eat meat.");
    }

    void sleep() {
        System.out.println("Dogs sleep for 12-14 hours a day.");
    }

    void makeSound() {
        System.out.println("Woof Woof");
    }
}