/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jhnnn
 */
class Bird extends Animal {
    void eat() {
        System.out.println("Birds love to eat seeds.");
    }

    void sleep() {
        System.out.println("Birds sleep for 10-12 hours a day.");
    }

    void makeSound() {
        System.out.println("Tweet tweet");
    }
}